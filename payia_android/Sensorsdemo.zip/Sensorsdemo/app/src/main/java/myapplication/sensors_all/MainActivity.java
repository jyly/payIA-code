package myapplication.sensors_all;

import android.app.Activity;
import android.app.AppOpsManager;
import android.app.usage.UsageStats;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

import jxl.Sheet;
import jxl.Workbook;
import jxl.write.Label;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

public class MainActivity extends Activity //implements SensorEventListener 最初是SensorListener
{
    private SensorManager mSensorManager;
    private String excelPath;//文件存储路径
    Timer timer = null;
    Timer timercheck = null;
    int warn = 0;
    int rightcheck = 0;
    TextView etGyro;
    TextView etMagnetic;
    TextView etLinearAcc;
    TextView etOri;
    TextView etLig;
    TextView etAcc;
    TextView etGra;
    TextView etPro;
    EditText inputfilename;//文件名输入框
    Button start;
    Button stop;
    float flag = 0;
    ArrayList<Float> AccList = new ArrayList<Float>();
    ArrayList<Float> LAccList = new ArrayList<Float>();
    ArrayList<Float> OriList = new ArrayList<Float>();
    ArrayList<Float> GyrList = new ArrayList<Float>();
    ArrayList<Float> MagList = new ArrayList<Float>();
    ArrayList<Float> LigList = new ArrayList<Float>();
    ArrayList<Float> ProList = new ArrayList<Float>();
    private float AccData[] = new float[3];
    private float LAccData[] = new float[3];
    private float OriData[] = new float[3];
    private float GyrData[] = new float[3];
    private float MagData[] = new float[3];
    private float LigData[] = new float[1];
    private float ProData[] = new float[1];
    ;
    private Workbook wb;
    private WritableWorkbook wbook;//需要导入jxl工程或者包
    private WritableSheet sh;
    private Sheet sheet;
    CreateXls data_XLS = new CreateXls();//需要导入工程或者jxl包


    private static final int MY_PERMISSIONS_REQUEST_PACKAGE_USAGE_STATS = 1101;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == MY_PERMISSIONS_REQUEST_PACKAGE_USAGE_STATS) {
            if (!hasPermission()) {
                //若用户未开启权限，则引导用户开启“Apps with usage access”权限
                startActivityForResult(
                        new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS),
                        MY_PERMISSIONS_REQUEST_PACKAGE_USAGE_STATS);
            }
        }
    }

    private boolean hasPermission() {
        AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
        int mode = 0;
        if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) {
            mode = appOps.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,
                    android.os.Process.myUid(), getPackageName());
        }
        return mode == AppOpsManager.MODE_ALLOWED;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //   myThread = new MyThread(this);
        if (!hasPermission()) {
            //若用户未开启权限，则引导用户开启“Apps with usage access”权限
            startActivityForResult(
                    new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS),
                    MY_PERMISSIONS_REQUEST_PACKAGE_USAGE_STATS);
        }
        start = (Button) findViewById(R.id.bn1);
        stop = (Button) findViewById(R.id.bn2);
        etGyro = (TextView) findViewById(R.id.etGyro);
        etLinearAcc = (TextView) findViewById(R.id.etLinearAcc);
        etAcc = (TextView) findViewById(R.id.etAcc);
        etMagnetic = (TextView) findViewById(R.id.etMagnetic);
        etOri = (TextView) findViewById(R.id.etOri);
        etLig = (TextView) findViewById(R.id.etLig);
        etPro = (TextView) findViewById(R.id.etPro);
        inputfilename = (EditText) findViewById(R.id.filename);
        mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        start.setOnClickListener(myListner);//为开始按钮和停止按钮添加监听器
        stop.setOnClickListener(myListner);
    }

    //开始和结束按钮监听器的外部实现
    private Button.OnClickListener myListner = new Button.OnClickListener() {
        @Override
        public void onClick(View v) {
            Log.i(">>>", "Service is start.");
            switch (v.getId()) {
                case R.id.bn1:  //开始按钮
                    StartSensorListening();//启动传感数据采集(注册三个传感器）
//                    if (inputfilename.getText().toString().equals("")) {
//                        StopSensorListening();//传感器失效
//                        break;
//                    }
                    //在SDcard给定路径下创建文件
                    excelPath = data_XLS.getExcelDir() + File.separator +
                            inputfilename.getText().toString() + ".xls";
                    Log.d("CC", excelPath);
                    data_XLS.excelCreate(new File(excelPath));

                    if (timer == null) {
                        timer = new Timer();
                    }
                    timer.schedule(new TimerTask() {
                        @Override
                        public void run() {
//                            if (0 == flag && getTopApp()) {
//                                Log.i(">>>", "top app is scan.");
                            AccList.add(AccData[0]);
                            AccList.add(AccData[1]);
                            AccList.add(AccData[2]);
                            GyrList.add(GyrData[0]);
                            GyrList.add(GyrData[1]);
                            GyrList.add(GyrData[2]);
                            MagList.add(MagData[0]);
                            MagList.add(MagData[1]);
                            MagList.add(MagData[2]);
                            OriList.add(OriData[0]);
                            OriList.add(OriData[1]);
                            OriList.add(OriData[2]);
                            LigList.add(LigData[0]);
                            ProList.add(ProData[0]);
                            LAccList.add(LAccData[0]);
                            LAccList.add(LAccData[1]);
                            LAccList.add(LAccData[2]);


//                            StringBuilder sb = null;
//
//                            sb = new StringBuilder();
//                            sb.append("绕X轴转过的角速度 gyr-x:");
//                            sb.append(GyrData[0]);
//                            sb.append("\n绕Y轴转过的角速度 gyr-y:");
//                            sb.append(GyrData[1]);
//                            sb.append("\n绕Z轴转过的角速度 gyr-z:");
//                            sb.append(GyrData[2]);
//                            etGyro.setText(sb.toString());
//                            sb = new StringBuilder();
//                            sb.append("绕X轴-磁场 mag-x:");
//                            sb.append(MagData[0]);
//                            sb.append("\n绕Y轴-磁场 mag-y:");
//                            sb.append(MagData[1]);
//                            sb.append("\n绕Z轴-磁场 mag-z:");
//                            sb.append(MagData[2]);
//                            etMagnetic.setText(sb.toString());
//                            sb = new StringBuilder();
//                            sb.append("X轴-方向计 ori-x:");
//                            sb.append(OriData[0]);
//                            sb.append("\nY轴-方向计 ori-y:");
//                            sb.append(OriData[1]);
//                            sb.append("\nZ轴-方向计 ori-z:");
//                            sb.append(OriData[2]);
//                            etOri.setText(sb.toString());
//                            sb = new StringBuilder();
//                            sb.append("X轴-加速度 acc-x:");
//                            sb.append(AccData[0]);
//                            sb.append("\nY轴-加速度 acc-y:");
//                            sb.append(AccData[1]);
//                            sb.append("\nZ轴-加速度 acc-z:");
//                            sb.append(AccData[2]);
//                            etLinearAcc.setText(sb.toString());
//                            sb = new StringBuilder();
//                            sb.append("X轴-线性加速度 lacc-x:");
//                            sb.append(LAccData[0]);
//                            sb.append("\nY轴-线性加速度 lacc-y:");
//                            sb.append(LAccData[1]);
//                            sb.append("\nZ轴-线性加速度 lacc-z:");
//                            sb.append(LAccData[2]);
//                            etAcc.setText(sb.toString());
//                            sb = new StringBuilder();
//                            sb.append("光度计 light:");
//                            sb.append(LigData[0]);
//                            etLig.setText(sb.toString());
//                            sb = new StringBuilder();
//                            sb.append("距离计 light:");
//                            sb.append(ProData[0]);
//                            etPro.setText(sb.toString());
//                            }
                        }
                    }, 5, 200);   //5ms后开始采集，每隔20ms采集一次,1秒采50次
                    inputfilename.setEnabled(false);//数据一旦开始采集，不允许输入文件名
                    stop.setEnabled(true);//关闭按钮启用
                    start.setEnabled(false);//开始按钮失效
                    break;
                case R.id.bn2:
                    StopSensorListening();//停止传感器采集
                    timer.cancel();//退出采集任务
                    timer = null;
                    inputfilename.setEnabled(true);
                    start.setEnabled(true);
                    stop.setEnabled(false);
//                    WriteXls(AccList, GyrList, MagList, OriList, LigList, LAccList,ProList);//核心代码：将采集的数据写入文件中
                    AccList.clear();//清除链表数据
                    LAccList.clear();//清除链表数据
                    OriList.clear();
                    GyrList.clear();
                    MagList.clear();
                    LigList.clear();
                    ProList.clear();
                    break;
            }
        }
    };


    private SensorEventListener listener = new SensorEventListener() {
        @Override
        public void onAccuracyChanged(Sensor sensor, int i) {
            //// TODO: 2018-4-8
        }

        public void onSensorChanged(SensorEvent e) {
            StringBuilder sb = null;
            switch (e.sensor.getType()) {

                case Sensor.TYPE_GYROSCOPE:     //陀螺传感器
                    sb = new StringBuilder();
                    sb.append("绕X轴转过的角速度 gyr-x:");
                    sb.append(e.values[0]);
                    sb.append("\n绕Y轴转过的角速度 gyr-y:");
                    sb.append(e.values[1]);
                    sb.append("\n绕Z轴转过的角速度 gyr-z:");
                    sb.append(e.values[2]);
                    etGyro.setText(sb.toString());
                    GyrData[0] = e.values[0];
                    GyrData[1] = e.values[1];
                    GyrData[2] = e.values[2];
                    break;
                case Sensor.TYPE_MAGNETIC_FIELD:    //磁场传感器
                    sb = new StringBuilder();
                    sb.append("绕X轴-磁场 mag-x:");
                    sb.append(e.values[0]);
                    sb.append("\n绕Y轴-磁场 mag-y:");
                    sb.append(e.values[1]);
                    sb.append("\n绕Z轴-磁场 mag-z:");
                    sb.append(e.values[2]);
                    etMagnetic.setText(sb.toString());

                    MagData[0] = e.values[0];
                    MagData[1] = e.values[1];
                    MagData[2] = e.values[2];
                    break;
                case Sensor.TYPE_ACCELEROMETER:   //加速度传感器
                    //   case Sensor.TYPE_ACCELEROMETER:   //加速度传感器
                    sb = new StringBuilder();
                    sb.append("X轴-加速度 acc-x:");
                    sb.append(e.values[0]);
                    sb.append("\nY轴-加速度 acc-y:");
                    sb.append(e.values[1]);
                    sb.append("\nZ轴-加速度 acc-z:");
                    sb.append(e.values[2]);
                    etLinearAcc.setText(sb.toString());
                    AccData[0] = e.values[0];
                    AccData[1] = e.values[1];
                    AccData[2] = e.values[2];
                    break;
                case Sensor.TYPE_ROTATION_VECTOR:   //加速度传感器
                    sb = new StringBuilder();
                    sb.append("X轴-方向计 ori-x:");
                    sb.append(e.values[0]);
                    sb.append("\nY轴-方向计 ori-y:");
                    sb.append(e.values[1]);
                    sb.append("\nZ轴-方向计 ori-z:");
                    sb.append(e.values[2]);
                    etOri.setText(sb.toString());
                    OriData[0] = e.values[0];
                    OriData[1] = e.values[1];
                    OriData[2] = e.values[2];
                    break;
                case Sensor.TYPE_LIGHT:   //光度传感器
                    sb = new StringBuilder();
                    sb.append("光度计 light:");
                    sb.append(e.values[0]);
                    etLig.setText(sb.toString());
                    LigData[0] = e.values[0];
                    break;
                case Sensor.TYPE_PROXIMITY:   //距离传感器
                    sb = new StringBuilder();
                    sb.append("距离计 light:");
                    sb.append(e.values[0]);
                    etPro.setText(sb.toString());
                    ProData[0] = e.values[0];
                    break;
                case Sensor.TYPE_LINEAR_ACCELERATION:   //线性加速度传感器
                    sb = new StringBuilder();
                    sb.append("X轴-线性加速度 lacc-x:");
                    sb.append(e.values[0]);
                    sb.append("\nY轴-线性加速度 lacc-y:");
                    sb.append(e.values[1]);
                    sb.append("\nZ轴-线性加速度 lacc-z:");
                    sb.append(e.values[2]);
                    etAcc.setText(sb.toString());
                    LAccData[0] = e.values[0];
                    LAccData[1] = e.values[1];
                    LAccData[2] = e.values[2];
                    break;

            }
        }
    };

        public void WriteXls(ArrayList<Float> accdata, ArrayList<Float> gyrdata,
                             ArrayList<Float> magdata, ArrayList<Float> oridata,
                             ArrayList<Float> Ligdata, ArrayList<Float> Laccdata,
                             ArrayList<Float> Prodata) {
            try {
                wb = Workbook.getWorkbook(new File(excelPath));//获取原始文档
                sheet = wb.getSheet(0);//得到一个工作对象
                wbook = Workbook.createWorkbook(new File(excelPath), wb);//根据book创建一个操作对象
                sh = wbook.getSheet(0);//得到一个工作
                //逐个写入加速度数据到文件中去！
                for (int i = 0, acc_Row = 1; i < accdata.size(); ) {
                    if (accdata != null && accdata.get(i) != null) {
                        for (int j = 0; j < 3; j++) {
                            Label label = new Label(j, acc_Row, String.valueOf(accdata.get(i)));
                            sh.addCell(label);
                            i++;
                        }
                        acc_Row++;
                    }
                }
                //逐个写入线性加速度数据到文件中去！
                for (int i = 0, lacc_Row = 1; i < Laccdata.size(); ) {
                    if (Laccdata != null && Laccdata.get(i) != null) {
                        for (int j = 3; j < 6; j++) {
                            Label label = new Label(j, lacc_Row, String.valueOf(Laccdata.get(i)));
                            sh.addCell(label);
                            i++;
                        }
                        lacc_Row++;
                    }
                }
                //逐个写入陀螺数据到文件中去！
                for (int i = 0, gyr_Row = 1; i < gyrdata.size(); ) {
                    if (gyrdata != null && gyrdata.get(i) != null) {
                        for (int j = 6; j < 9; j++) {
                            Label label = new Label(j, gyr_Row, String.valueOf(gyrdata.get(i)));
                            sh.addCell(label);
                            i++;
                        }
                        gyr_Row++;
                    }
                }
                //逐个写入磁力计数据到文件中去！
                for (int i = 0, mag_Row = 1; i < magdata.size(); ) {
                    if (magdata != null && magdata.get(i) != null) {
                        for (int j = 9; j < 12; j++) {
                            Label label = new Label(j, mag_Row, String.valueOf(magdata.get(i)));
                            sh.addCell(label);
                            i++;
                        }
                        mag_Row++;
                    }
                }
                //逐个写入方向计数据到文件中去！
                for (int i = 0, ori_Row = 1; i < oridata.size(); ) {
                    if (oridata != null && oridata.get(i) != null) {
                        for (int j = 12; j < 15; j++) {
                            Label label = new Label(j, ori_Row, String.valueOf(oridata.get(i)));
                            sh.addCell(label);
                            i++;
                        }
                        ori_Row++;
                    }
                }
                //逐个写入光度计数据到文件中去！
                for (int i = 0, Lig_Row = 1; i < Ligdata.size(); ) {
                    if (Ligdata != null && Ligdata.get(i) != null) {
                        for (int j = 18; j < 19; j++) {
                            Label label = new Label(j, Lig_Row, String.valueOf(Ligdata.get(i)));
                            sh.addCell(label);
                            i++;
                        }
                        Lig_Row++;
                    }
                }
//            //逐个写入光度计数据到文件中去！
//            for (int i = 0, pro_Row = 1; i < Prodata.size(); ) {
//                if (Prodata != null && Prodata.get(i) != null) {
//                    for (int j = 19; j < 20; j++) {
//                        Label label = new Label(j, pro_Row, String.valueOf(Prodata.get(i)));
//                        sh.addCell(label);
//                        i++;
//                    }
//                    pro_Row++;
//                }
//            }

            //写入数据
            wbook.write();
            wbook.close();
        } catch (Exception e2) {
            System.out.print(e2.toString() + "--");
            System.out.print("--异常--");
        }
    }

    public void StartSensorListening() {
        super.onResume();
        //陀螺传感器注册监听器
        mSensorManager.registerListener(listener, mSensorManager.getDefaultSensor(
                Sensor.TYPE_GYROSCOPE), SensorManager.SENSOR_DELAY_FASTEST);
        //磁场传感器注册监听器
        mSensorManager.registerListener(listener, mSensorManager.getDefaultSensor(
                Sensor.TYPE_MAGNETIC_FIELD), SensorManager.SENSOR_DELAY_FASTEST);
        //加速度传感器注册监听器
        mSensorManager.registerListener(listener, mSensorManager.getDefaultSensor(
                Sensor.TYPE_ACCELEROMETER), SensorManager.SENSOR_DELAY_FASTEST);
        //方向计传感器注册监听器
        mSensorManager.registerListener(listener, mSensorManager.getDefaultSensor(
                Sensor.TYPE_ROTATION_VECTOR), SensorManager.SENSOR_DELAY_FASTEST);
        //光度计传感器注册监听器
        mSensorManager.registerListener(listener, mSensorManager.getDefaultSensor(
                Sensor.TYPE_LIGHT), SensorManager.SENSOR_DELAY_FASTEST);
        //线性加速度传感器注册监听器
        mSensorManager.registerListener(listener, mSensorManager.getDefaultSensor(
                Sensor.TYPE_LINEAR_ACCELERATION), SensorManager.SENSOR_DELAY_FASTEST);
        //距离传感器注册监听器
        mSensorManager.registerListener(listener, mSensorManager.getDefaultSensor(
                Sensor.TYPE_PROXIMITY), SensorManager.SENSOR_DELAY_FASTEST);
//        List<Sensor> sensorList = mSensorManager.getSensorList(Sensor.TYPE_ALL);
//        for (Sensor sensor : sensorList) {
//            Log.e(">>>>", "type="+sensor.getType());
//        }


    }

    public void StopSensorListening() {
        mSensorManager.unregisterListener(listener);
    }

    //判断是否当前使用的应用时要求监听的应用，是则返回真，没有则返回否
    private boolean getTopApp() {
        //判断权限
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            UsageStatsManager m = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
            if (m != null) {
                long now = System.currentTimeMillis();
                //获取60秒之内的应用数据
                List<UsageStats> stats = m.queryUsageStats(UsageStatsManager.INTERVAL_BEST, now - 5 * 1000, now);
                //  Log.i(">>>", "Running app number in last 60 seconds : " + stats.size());
                String topActivity = "";
                //取得最近运行的一个app，即当前运行的app
                if ((stats != null) && (!stats.isEmpty())) {
                    int j = 0;
                    for (int i = 0; i < stats.size(); i++) {
                        if (stats.get(i).getLastTimeUsed() > stats.get(j).getLastTimeUsed()) {
                            j = i;
                        }
                    }
                    topActivity = stats.get(j).getPackageName();
                }
                //此处判断正在运行的是否为你监听的app，括号内是应用的包名
                if (topActivity.equals("com.huyi.scancode")) {
                    //  Log.i(">>>", "top running app is : " + topActivity);
                    return true;
                }
                return false;
            }
        }
        return false;
    }


}
