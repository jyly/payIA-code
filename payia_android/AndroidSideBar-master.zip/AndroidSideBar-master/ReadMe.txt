1,ui美化
2,开机启动
3,去除启动图标
4,去除activity